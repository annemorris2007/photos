# Playground

This page allows to test (almost) all options of Photo Sphere Viewer with your own panorama (equirectangular only). You can also add markers interractively and export them.

<no-ssr>
  <Playground/>
</no-ssr>
